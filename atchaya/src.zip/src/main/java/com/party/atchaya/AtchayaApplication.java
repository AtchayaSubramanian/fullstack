package com.party.atchaya;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AtchayaApplication {

	public static void main(String[] args) {
		SpringApplication.run(AtchayaApplication.class, args);
	}

}
