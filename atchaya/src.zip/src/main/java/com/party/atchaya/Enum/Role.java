package com.party.atchaya.Enum;

public enum Role {
ADMIN,USER
}
